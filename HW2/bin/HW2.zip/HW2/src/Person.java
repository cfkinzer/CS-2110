// Christian Kinzer
// cfk5ax
// HW2

import java.util.ArrayList;

public class Person {
	private String name;
	private int id;
	private ArrayList<Book> read;

	public Person(String nombre, int num) { //constructor
		name = nombre;
		id = num;
		read = new ArrayList<Book>();
	}

	public String getName() { //getter for name
		return name;
	}
	public int getId() { //getter for id
		int num = id;
		return num;
	}
	public ArrayList<Book> getRead(){ //getter for read
		return read;
	}

	public void setName(String name) { //setter for name
		this.name = name;
	}

	public boolean hasRead(Book b) { //checks if someone has read a book
		if(read.contains(b)) {
			return true;
		}
		else {
			return false;
		}
	}

	public boolean addBook(Book b) { //adds a book to someone's read list
		if(!read.contains(b)) {
			read.add(b);
			return true;
		}
		else {
			return false;
		}
	}

	public boolean forgetBook(Book b) { //removes a book from someone's read list
		if(read.contains(b)) {
			read.remove(b);
			return true;
		}
		else {
			return false;
		}
	}

	public int numBooksRead() { //returns number of books in one's readlist
		return read.size();
	}

	public boolean equals(Object o) { //checks if two people have the same id
		if(o instanceof Person) {
			Person p = (Person)o;
			int num = this.id;
			return num == p.id;
		}
		else {
			return false;
		}
	}

	public String toString() { //returns a string of a person, their name, and their read books
		String booksRead = read.toString();
		return name + " (" + id + ") " + "has read the following books: " + booksRead;
	}

	public static ArrayList<Book> commonBooks(Person a, Person b){ //returns an arraylist of books two people have both
		ArrayList<Book> inCommon = new ArrayList<Book>();
		for(Book i : a.read) {
			if(b.read.contains(i)) {
				inCommon.add(i);
			}
		}
		return inCommon;
	}

	public static double similarity(Person a, Person b) { //returns a similarity rating for two people's read lists
		double denom = 1;
		if(a.read.size() <= b.read.size()) {
			denom = a.read.size();
		}
		if(b.read.size() < a.read.size()) {
			denom = b.read.size();
		}
		ArrayList<Book> common = commonBooks(a, b);
		double num = common.size();
		return num / denom;
	}

}
