// Christian Kinzer
// cfk5ax
// HW2

public class Book {
	private String title;
	private String author;

	public Book(String book, String writer) {
		title = book;
		author = writer;
	}

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public boolean equals(Object o) {
		if(o instanceof Book) {
			Book b = (Book)o;
			return (this.title.equals(b.title) && this.author.equals(b.author));
		}
		else {
			return false;
		}
	}

	public String toString() {
		return title + ", by " + author;
	}
}
